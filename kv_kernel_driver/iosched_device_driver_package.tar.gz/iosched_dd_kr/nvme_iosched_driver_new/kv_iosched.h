/*
 * NVM Express Key-value device driver
 * Copyright (c) 2016-2018, Samsung electronics.
 *
 * Author : Heekwon Park
 * E-mail : heekwon.p@samsung.com
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 */
#ifndef _KV_IOSCHED_H
#define _KV_IOSCHED_H
#include <linux/blkdev.h>
#include <linux/spinlock.h>
#include <linux/types.h>
#include <linux/freezer.h>
#include "kv_fifo.h"
#include "nvme.h"
#include "linux_nvme_ioctl.h"
#define KV_HASH_BITS	17
#define KV_HASH_SIZE	(1UL << KV_HASH_BITS)

#define KV_KEY_SUCCESS 0
#define KV_KEY_EXIST 1

#define DELAYED_COMPLETE_WORK

enum{
    KV_flush_begin = 0,
    KV_flush_done= 1,
    KV_flush_cancel= 2,
    KV_flush_end = 3,
    KV_flush_nr = 4,
};
enum{
    KV_hash_com_insert= 0,
    KV_hash_inv_insert= 1,
    KV_hash_blk_insert= 2,
    KV_hash_com_sync= 3,
    KV_hash_inv_sync= 4,
    KV_hash_blk_sync= 5,
    KV_hash_restart_nr= 6,
};

extern atomic_t kv_total_async_request;
extern atomic_t kv_total_get_async_merge;
extern atomic_t kv_total_put_del_async_merge;
extern atomic_t kv_total_async_submit;
extern atomic_t kv_total_sync_submit;
extern atomic_t kv_total_blocked_submit;
extern atomic_t kv_total_async_interrupt;
extern atomic_t kv_total_async_complete;
extern atomic_t kv_total_sync_complete;
extern atomic_t kv_completion_retry;
extern atomic_t kv_completion_rq_empty;
extern atomic_t kv_completion_wakeup;
extern atomic_t kv_completion_wakeup_by_submit;
extern atomic_t kv_completion_wakeup_by_int;
extern atomic_t kv_flush_wakeup_by_submit;
extern atomic_t kv_flush_wakeup_by_completion;
extern atomic_t kv_flush_statistics[KV_flush_nr];
extern atomic_t kv_hash_restart[KV_hash_restart_nr];
extern atomic_t kv_readahead_kv_count;

extern char kvct_sync_io[8][255];
extern char kvct_ioctl[8][255];
extern char kvct_submission[255];
extern char kvct_int_handle[255];
extern char kvct_completion[255];


/*
 * Hash 0(KV_RQ_HASH)     : Request HASH
 * Hash 1(KV_RA_HASH)     : Read-ahead HASH
 */
enum{
    KV_RQ_HASH		= 0,
    KV_RA_HASH      = 1,
    NR_KV_HASH		= 2,
};

/*
 * Hash table
 */
struct kv_hash{
    struct hlist_head hashtable[KV_HASH_SIZE];
    spinlock_t hash_lock[KV_HASH_SIZE];
    /*
     * Number of entries in this hashtable
     *  - Decide size of hash table ; if entries are too many, the size should be increased.
     *  - Tracking number of read-ahead data for page reclaiming
     * TODO
     * nr_rq may not be neccessary
     */
    atomic_t nr_rq; 
    /*
     * Only buffer Q can be congested
     * because the submission Q is immutable 
     * which means do not take requests anymore
     * So, we move congesion indicator to kv_iosched_struct->state:KV_iosched_congested
     *
     * We also move number of congestion to kv_iosched_struct.
     */
#if 0
    atomic_t congestion;
    atomic_t nr_congested;
#endif
};



enum kv_iosched_state {
	KV_iosched_registered,		/* kv_iosched_init() was done */
	KV_iosched_congested,	/* The limit number of in-flight request has been reached */
	KV_iosched_flush,	/* The limit number of in-flight request has been reached */
};

enum kv_async_rq_state{
    KV_async_invalid_rq = 0, 
    KV_async_blocking_rq = 1,
    KV_async_inFlight_rq = 2,
    KV_async_SaS = 3, //Save after Store : (move to readahead hash)
    KV_async_flush_wakeup = 4, //Wake the flush daemon which is waiting for this rq when this rq is completed.
    KV_async_in_readahead = 5, //The resquest has been inserted to readahead hash
    KV_async_completed= 6, // The request has been completed.
#if 0
    KV_async_inUse_rq = 3, 
    KV_async_read_rq = 1, 
    KV_async_write_rq = 2, 
#endif
};

#if 1
/*
 * This is for 16 bytes embed key of PHX
 */
typedef struct {
	u64 m_low;
	u64 m_high;
} uint128_t;
////////////// code for 16 byte embedded  key /////////////////
/*
 * This is for 16 bytes key in PHX
 */
static inline u64 __hash_64(u64 val)
{
    return val * GOLDEN_RATIO_64;
}
static __always_inline u64 hash_128(uint128_t val, unsigned int bits){
    /* Hash 128 bits using only 64x64-bit multiply. */
    return hash_64((u64)val.m_low ^ __hash_64(val.m_high), bits);
}
#endif

#define KV_SUCCESS 0

#define KV_ASYNC_INTERVAL 500
/*
 *
 */
#if 0
#define KV_MAX_INFLIGHT_REQUEST 128 
#elif 0
/* 
 * The device does not hang when requesting get in single threaded async mode(burst I/O)  
 */
#define KV_MAX_INFLIGHT_REQUEST 240
#elif 0
/* 
 * The device does not hang when requesting get in single threaded async mode(burst I/O)  
 */
#define KV_MAX_INFLIGHT_REQUEST 272
#elif 0
/* 
 * The device hangs when requesting get in async mode(burst I/O) 
 */
#define KV_MAX_INFLIGHT_REQUEST 384
#else
/* 
 * The device hangs when requesting get in async mode(burst I/O) 
 * But no requests are blocked in this configuration
 */
#define KV_MAX_INFLIGHT_REQUEST 1024
#endif
#define DEFAULT_NR_REQ_PER_MEMQ 32

//#define KV_TIME_MEASUREMENT

/*
 * Memory Queue structure
 * * Active MemQueue
 *  - Buffering new requests 
 *  - Allow to modify existing requests
 * * Mutable MemQueue
 *  - Does not receive new requests 
 *  - Allow to modify existing requests
 *  - Waiting for submission 
 *
 * 
 */
struct kv_memqueue_struct{
    struct list_head memq_lru; /* linked list for mutable Memory Queue list */
    struct list_head rq; /* linked list for user requests */

    atomic_t nr_pending;

    atomic_t nr_rq; /* Number of entries in the Memory Queue list*/

    struct kv_iosched_struct *kv_iosched;

    /*
     * How many sync operations are wait for completion of the Memory Queue.
     * If sync_wait is not 0, completion daemon do not move forward.
     *  : Do not clear pending status
     * It means that sync operations are waiting for this Memory Queue 
     * because they have same key with a request in the Memory Queue.
     * The daemon should be wait the sync_wait to be 0.
     */
};

struct kv_async_request{
    ////////////// Set in user context to insert to hash list //////////
    struct	request_queue *queue;
	//__u8			opcode;
    struct	nvme_command c;
    unsigned	timeout;
    unsigned long state;

    void	*data_addr;
    __u32	data_length;
    /*
     * If the data size is larger than 
     * KVCMD_INLINE_KEY_MAX(PHX = 16 bytes), 
     * metadata stores base address of the data and set metadata_len. 
     * Otherwise, the metadata is saved in c.common.metadata. 
     * In this case, the metadata_len is set to 0.
     */
    void	*key_addr; 
    __u32	key_length;
    ////////////// end  //////////

    ////////////// set in flush daemon before/after completion  //////////
    /*
     * Keep the "struct request *" in order to free the structure
     */
    struct request *req;
    /*
     * cqe = nvme_competion
     */
    struct nvme_completion cqe;
    /*
     * result = le32_to_cpu(cqe.result);
     */
    __u32	result; 
    /*
     * struct request *req;
     * ret = req->errors;
     */
    /*
     * Point to the request blocking this request.
     */
    struct kv_async_request *blocking_rq;
    spinlock_t lock;		/* protects data */

    //for re-insertion	:  the same key already exist in one of Qs
    //for migration	: submission => readahead q
    u32 hash_key;

    /*
     * For add it to hash list(Submission or Read-Hhead hash)
     */
    struct hlist_node hash;
    /*
     * For add it to memq_struct
     * lru in readahead queue
     */
    struct list_head lru;
    struct kv_memqueue_struct *memq;
	atomic_t refcount;
    struct kv_iosched_struct *iosched;
};

struct kv_sync_request{
    struct request_queue *q;
    struct nvme_command c;
    void __user *udata_addr;   // from User
    unsigned udata_length;
    void *key_addr; 
    unsigned key_length;
    u32 result; 
    unsigned timeout;
};

struct kv_dwork_struct{
    struct workqueue_struct *wq;
    struct delayed_work dwork;
    void *addr;
};

struct kv_iosched_struct{

    /* 
     * Scheduling daemon.
     * Create the daemons as many as the # of CPUs
     * We cannot use "container_of" macro for __percpu data structure.
     * That's why we define "kv_dwork_struct"
     */
    struct kv_dwork_struct __percpu *schedd;
    /*
     * Submission & compleation daemons
     * These daemons are not delayed work queue, scheduled immediately
     */
    struct workqueue_struct *submit_wq;
    struct work_struct submit_work;
    spinlock_t work_lock;/* protects work_list & dwork scheduling */

    struct workqueue_struct *complete_wq;
#ifdef DELAYED_COMPLETE_WORK
    struct delayed_work complete_dwork;
    unsigned long complete_delay;
    unsigned int complete_max_rq;
#else
    struct work_struct complete_work;
#endif
    spinlock_t complete_lock;/* protects work_list & dwork scheduling */
    struct kv_fifo complete_fifo;

    /*
     * Per CPU active list
     */
    struct kv_memqueue_struct **__percpu active_memq;
    struct kv_memqueue_struct **__percpu reserved_memq;
    int max_nr_req_per_memq;


    struct list_head mumemq_list; /* Mutable Memory Queue list */
    spinlock_t mumemq_lock;

    /* Submission & read-ahead hash tables */
    struct kv_hash kv_hash[NR_KV_HASH];
    /* 
     * This lru is only used in read-ahead hash.
     */
    spinlock_t ra_lock; /* read ahead list locks */
    struct list_head ra_list; /* read ahead list for reclaim */

    atomic_t nr_congested;
    atomic_t in_flight_rq;
    atomic_t nr_flush_rq;
    unsigned long state;	/* workqueue & congestion status. */
};//kv_iosched_struct

/*
 * Workqueue init/destroy function
 */
extern int kv_iosched_init(struct kv_iosched_struct *, int);
extern void kv_iosched_destroy(struct kv_iosched_struct *);

/*
 * Workqueue related functions
 */
extern void kv_sched_flush_workqueue(struct kv_iosched_struct *kv_iosched);
extern bool kv_sched_wakeup_delayed(int cpu, struct kv_iosched_struct *kv_iosched, unsigned int msec);
extern void kv_sched_wakeup_immediately(int cpu, struct kv_iosched_struct *kv_iosched);
extern void kv_sched_cancel_work(int cpu, struct kv_iosched_struct *kv_iosched);


/*
 * IO Schedule core function
 */
extern int __nvme_submit_iosched_kv_cmd(struct kv_memqueue_struct *memq);

/*
 * Allocate a data structure from SLAB
 */
extern inline struct kv_async_request *kv_async_request_alloc(void);
extern inline void kv_async_request_free(struct kv_async_request *rq);
extern inline struct kv_sync_request *kv_sync_request_alloc(void);
extern inline void kv_sync_request_free(struct kv_sync_request *rq);

extern void kv_hash_init(struct kv_hash *);
extern struct kv_async_request * kv_hash_insert(struct kv_hash *, struct kv_async_request *);
extern struct kv_async_request *kv_hash_insert_readahead(struct kv_hash *hash, struct kv_async_request *rq);
extern struct kv_async_request *kv_hash_find(struct kv_hash *, void *, __u32, u32 );
extern int kv_hash_delete_readahead(struct kv_hash *hash, struct kv_async_request *rq);
extern int kv_hash_delete(struct kv_hash *, struct kv_async_request *);
extern struct kv_async_request *kv_hash_find_and_lock(struct kv_hash *hash, void *key, u32 key_length, u32 hash_key, bool *inFlight);
extern struct kv_async_request *kv_hash_find_and_lock_pending_rq(struct kv_hash *, void *, __u32 , u32);
extern struct kv_async_request *kv_hash_find_and_del_readahead(struct kv_hash *hash, void *key, u32 key_length, u32 hash_key);


static inline void free_kv_async_rq(struct kv_async_request *rq){

    if(rq->key_length > KVCMD_INLINE_KEY_MAX && rq->key_addr){
        kfree(rq->key_addr);
        rq->key_addr = NULL;
    }
    if(rq->data_addr){
        kfree(rq->data_addr);
        rq->data_addr = NULL;
    }
    rq->key_length = 0;
    rq->data_length = 0;
    rq->hash_key = KV_HASH_SIZE;
    rq->req = NULL;
    rq->state = 0;
    rq->memq = NULL;
    spin_unlock(&rq->lock);
    kv_async_request_free(rq);
}

static inline int kv_wait_killable(int mode)
{
    freezable_schedule_unsafe();
    if (signal_pending_state(mode, current))
        return -ERESTARTSYS;
    return 0;
}

static inline int kv_wait_atomic_killable(atomic_t *p)
{
    return kv_wait_killable(TASK_KILLABLE);
}

#endif
