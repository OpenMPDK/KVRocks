/*
 * kv_worker.h 
 * Author : Heekwon Park
 * E-mail : heekwon.p@samsung.com
 */
#ifndef KV_WORKER_H
#define KV_WORKER_H
extern void *worker_func(void *data);
#endif /* KV_WORKER_H */
