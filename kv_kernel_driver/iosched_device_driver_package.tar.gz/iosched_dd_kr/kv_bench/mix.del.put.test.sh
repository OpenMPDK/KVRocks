cp thread.mix.del.put.conf thread.default.conf 
echo > /proc/kv_proc
./kv_bench -u n
