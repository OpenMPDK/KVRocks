sed -n '$=' ./key.list
