cp thread.mix.get.del.conf thread.default.conf 
echo > /proc/kv_proc
./kv_bench -u n
