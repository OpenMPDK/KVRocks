cp thread.put.conf thread.default.conf 
echo > /proc/kv_proc
./kv_bench -u n
