cp thread.get.t1.conf thread.default.conf 
echo > /proc/kv_proc
./kv_bench -u n
