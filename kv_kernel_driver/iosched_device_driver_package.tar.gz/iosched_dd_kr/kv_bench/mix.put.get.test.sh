cp thread.mix.put.get.conf thread.default.conf 
echo > /proc/kv_proc
./kv_bench -u n
