cp thread.all.conf thread.default.conf 
echo > /proc/kv_proc
./kv_bench -u n
