cp  thread.del.conf thread.default.conf
echo > /proc/kv_proc
./kv_bench -u f
